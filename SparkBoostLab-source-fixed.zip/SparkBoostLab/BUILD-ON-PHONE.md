# Build SparkBoost Lab APK using only your phone

You do not need a PC. This creates a debug APK in GitHub Actions. The APK is not prebuilt or independently tested yet; GitHub must compile the source first.

## 1. Create a repository

1. In your phone browser, open https://github.com/new and sign in.
2. Repository name: `SparkBoostLab`. Private is fine.
3. Leave **Add a README**, `.gitignore`, and license unchecked, then create the repository.

## 2. Upload the project files

1. Extract `SparkBoostLab-source.zip` on your phone.
2. Open the extracted `SparkBoostLab` folder.
3. In your GitHub repository, choose **Add file → Upload files** and upload the project files. The repository root must contain `settings.gradle`, `build.gradle`, `gradle.properties`, `README.md`, and the `app` folder.

**Important: the workflow file is inside a hidden folder named `.github`.** Some Android file pickers hide dot-folders or do not upload folders. If you cannot upload `.github/workflows/build-apk.yml`, create it directly on GitHub as described in Step 3. The workflow will not appear in Actions until this file is in the repository at the exact path `.github/workflows/build-apk.yml`.

Commit the uploaded files when GitHub asks.

## 3. If the workflow is missing, create it on GitHub

1. In the repository, tap **Add file → Create new file**.
2. For the filename, enter exactly: `.github/workflows/build-apk.yml`
3. Copy the entire YAML block below into the editor, then commit the new file to the `main` branch.

```yaml
name: Build SparkBoost Lab APK

on:
  workflow_dispatch:
  push:
    branches: [ main, master ]

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Check out source
        uses: actions/checkout@v4

      - name: Set up Java 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Android SDK packages
        run: sdkmanager "platform-tools" "platforms;android-36" "build-tools;36.0.0"

      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.13'

      - name: Build debug APK
        run: gradle --no-daemon assembleDebug

      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: SparkBoost-Lab-debug-APK
          path: app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
          retention-days: 7
```

## 4. Run the build

1. Open the repository's **Actions** tab.
2. Select **Build SparkBoost Lab APK** from the workflow list.
3. Tap **Run workflow** if it is offered. The workflow also starts automatically after a push to `main` or `master`.
4. Open the newest run and wait for it to finish. If it fails, open the failed job and share the error text or a screenshot so the build can be fixed.

## 5. Download and install

1. On a successful run, scroll to **Artifacts** and download `SparkBoost-Lab-debug-APK`.
2. Extract that downloaded ZIP. It should contain `app-debug.apk`.
3. Tap the APK to install it. Android may ask you to permit installs from the browser or file manager.

## Limits and safety

- A successful build means the source compiled; it does not prove all features work on your phone.
- This is a debug build for personal testing, not a Play Store release.
- CPU/GPU frequency control is not available from an ordinary app without appropriate privileged access/root. Do not assume the app can force hardware clocks.
- Only install an APK you built from source you inspected and trust. Do not put passwords, access tokens, or private keys in the repository.
