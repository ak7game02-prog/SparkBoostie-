Create this file in your GitHub repository at the exact path `.github/workflows/build-apk.yml` if the hidden `.github` folder was not uploaded. Copy the YAML block from `BUILD-ON-PHONE.md`, under “If the workflow is missing, create it on GitHub.”

The workflow is only detected after it is committed to the repository. It is not a built-in GitHub workflow.
