package com.sparkboost.tecno;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int SHIZUKU_REQUEST_CODE = 5107;
    private TextView statusText;
    private TextView thermalText;
    private TextView outputText;
    private Button permissionButton;

    private final Shizuku.OnRequestPermissionResultListener permissionListener =
            (requestCode, grantResult) -> runOnUiThread(() -> {
                if (requestCode == SHIZUKU_REQUEST_CODE) {
                    updateStatus();
                    Toast.makeText(this,
                            grantResult == PackageManager.PERMISSION_GRANTED
                                    ? "Shizuku access granted" : "Shizuku access not granted",
                            Toast.LENGTH_SHORT).show();
                }
            });

    private final Shizuku.OnBinderReceivedListener binderReceivedListener = this::updateStatus;
    private final Shizuku.OnBinderDeadListener binderDeadListener = this::updateStatus;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        Shizuku.addRequestPermissionResultListener(permissionListener);
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener);
        Shizuku.addBinderDeadListener(binderDeadListener);
        updateStatus();
        updateThermalStatus();
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        Shizuku.removeBinderReceivedListener(binderReceivedListener);
        Shizuku.removeBinderDeadListener(binderDeadListener);
        super.onDestroy();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(24), dp(20), dp(28));
        page.setBackgroundColor(0xFFF3F5F9);
        scroll.addView(page);

        TextView title = new TextView(this);
        title.setText("SparkBoost Lab");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(0xFF101827);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Tecno SPARK 50 5G · device-specific performance companion");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF536174);
        subtitle.setPadding(0, dp(5), 0, dp(16));
        page.addView(subtitle);

        statusText = sectionText(page, "Shizuku status: checking…");
        thermalText = sectionText(page, "Thermal status: checking…");

        permissionButton = button("Request / refresh Shizuku access", v -> requestShizuku());
        page.addView(permissionButton);
        page.addView(button("Run read-only device scan", v -> runDiagnostics()));

        addHeading(page, "Launch a game");
        page.addView(button("Mobile Legends: Bang Bang", v -> launchPackage("com.mobile.legends")));
        page.addView(button("Roblox", v -> launchPackage("com.roblox.client")));
        page.addView(button("Free Fire MAX", v -> launchPackage("com.dts.freefiremax")));

        addHeading(page, "GPU-light profile · optional");
        TextView profileNote = new TextView(this);
        profileNote.setText("Sets Android custom game mode to 80% render scale, if your system accepts it. This may reduce GPU workload but makes the image less sharp; FPS is not unlocked or capped by this profile. You can restore the standard configuration below.");
        profileNote.setTextColor(0xFF536174);
        profileNote.setTextSize(12);
        profileNote.setPadding(0, 0, 0, dp(10));
        page.addView(profileNote);
        addGameProfileControls(page, "MLBB", "com.mobile.legends");
        addGameProfileControls(page, "Roblox", "com.roblox.client");
        addGameProfileControls(page, "Free Fire MAX", "com.dts.freefiremax");

        addHeading(page, "Diagnostic output");
        outputText = new TextView(this);
        outputText.setText("Run a scan to inspect available Android controls. No settings have been changed.");
        outputText.setTextColor(0xFF202A38);
        outputText.setTextSize(12);
        outputText.setTypeface(Typeface.MONOSPACE);
        outputText.setTextIsSelectable(true);
        outputText.setPadding(dp(12), dp(12), dp(12), dp(12));
        outputText.setBackgroundColor(0xFFFFFFFF);
        page.addView(outputText, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("Honest limits: this app does not root the phone, force CPU/GPU clocks, unlock unsupported FPS, or claim hidden performance gains. Shizuku only grants the shell-level access you explicitly authorize; Android may still block individual controls.");
        note.setTextColor(0xFF536174);
        note.setTextSize(12);
        note.setPadding(0, dp(16), 0, 0);
        page.addView(note);
        setContentView(scroll);
    }

    private TextView sectionText(LinearLayout parent, String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(14);
        view.setTextColor(0xFF1B293A);
        view.setPadding(dp(12), dp(12), dp(12), dp(12));
        view.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        parent.addView(view, lp);
        return view;
    }

    private void addHeading(LinearLayout parent, String text) {
        TextView heading = new TextView(this);
        heading.setText(text);
        heading.setTextSize(17);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setTextColor(0xFF101827);
        heading.setPadding(0, dp(18), 0, dp(8));
        parent.addView(heading);
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(7);
        b.setLayoutParams(lp);
        return b;
    }

    private void updateStatus() {
        runOnUiThread(() -> {
            boolean connected = Shizuku.pingBinder();
            boolean granted = connected && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
            statusText.setText("Shizuku: " + (connected ? (granted ? "connected · permission granted" : "connected · permission needed") : "not running / not connected")
                    + "\nAndroid " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
            permissionButton.setEnabled(connected);
            permissionButton.setText(granted ? "Shizuku access granted · refresh status" : "Request / refresh Shizuku access");
        });
    }

    private void updateThermalStatus() {
        String state = "Thermal status: not available";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                int t = pm.getCurrentThermalStatus();
                String[] names = {"none", "light", "moderate", "severe", "critical", "emergency", "shutdown"};
                state = "Android thermal status: " + (t >= 0 && t < names.length ? names[t] : t)
                        + "\nThis is a system severity level, not a direct CPU/GPU temperature reading.";
            }
        }
        thermalText.setText(state);
    }

    private void requestShizuku() {
        if (!Shizuku.pingBinder()) {
            Toast.makeText(this, "Start Shizuku first, then return here.", Toast.LENGTH_LONG).show();
            return;
        }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            updateStatus();
            Toast.makeText(this, "Shizuku permission is already granted.", Toast.LENGTH_SHORT).show();
        } else {
            Shizuku.requestPermission(SHIZUKU_REQUEST_CODE);
        }
    }

    private void launchPackage(String packageName) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch == null) {
                Toast.makeText(this, "That game is not installed or has no launch activity.", Toast.LENGTH_LONG).show();
                return;
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (Exception e) {
            Toast.makeText(this, "Could not launch game: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    private void addGameProfileControls(LinearLayout parent, String label, String packageName) {
        TextView gameLabel = new TextView(this);
        gameLabel.setText(label);
        gameLabel.setTextSize(14);
        gameLabel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        gameLabel.setTextColor(0xFF263449);
        gameLabel.setPadding(0, dp(5), 0, dp(2));
        parent.addView(gameLabel);
        parent.addView(button("Apply 80% render scale · " + label,
                v -> confirmGameProfile(packageName, true)));
        parent.addView(button("Restore standard configuration · " + label,
                v -> confirmGameProfile(packageName, false)));
    }

    private void confirmGameProfile(String packageName, boolean apply) {
        if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Start Shizuku and grant access first.", Toast.LENGTH_LONG).show();
            updateStatus();
            return;
        }
        String action = apply
                ? "Apply an 80% render scale and select Android custom game mode for this game? Image sharpness may decrease."
                : "Remove this app's custom Game Manager configuration and select standard mode?";
        new AlertDialog.Builder(this)
                .setTitle(apply ? "Apply GPU-light profile" : "Restore standard profile")
                .setMessage(action + "\n\nThe command will be verified by reading Game Manager's response. If the phone rejects it, the output will show the error.")
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .setPositiveButton(apply ? "Apply" : "Restore", (dialog, which) -> runGameProfileCommand(packageName, apply))
                .show();
    }

    private void runGameProfileCommand(String packageName, boolean apply) {
        outputText.setText("Running and verifying Game Manager command…");
        new Thread(() -> {
            String command;
            if (apply) {
                command = "cmd game set --downscale 0.8 " + packageName + " 2>&1 && " +
                        "cmd game mode custom " + packageName + " 2>&1 && " +
                        "echo '=== VERIFY CONFIG ===' && cmd game list-configs " + packageName + " 2>&1 && " +
                        "echo '=== VERIFY MODE ===' && cmd game list-modes " + packageName + " 2>&1";
            } else {
                command = "cmd game reset " + packageName + " 2>&1 && " +
                        "cmd game mode standard " + packageName + " 2>&1 && " +
                        "echo '=== VERIFY CONFIG ===' && cmd game list-configs " + packageName + " 2>&1 && " +
                        "echo '=== VERIFY MODE ===' && cmd game list-modes " + packageName + " 2>&1";
            }
            String result = runShell(command);
            final String display = (result == null ? "No output returned." : result) +
                    "\n\nNote: configuration output confirms what Android reports; it does not guarantee a measurable FPS improvement. Restart the game if Android requests it or the change is not visible.";
            runOnUiThread(() -> outputText.setText(display));
        }).start();
    }

    private void runDiagnostics() {
        if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            outputText.setText("Shizuku is not connected with permission. Start Shizuku and grant access, then run the scan again.\n\nNo settings were changed.");
            updateStatus();
            return;
        }
        outputText.setText("Scanning… (read-only)");
        new Thread(() -> {
            String script = "echo '=== DEVICE ==='; getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.sdk; " +
                    "echo '=== GAME MANAGER HELP ==='; cmd game help 2>&1 | head -n 70; " +
                    "echo '=== MLBB CONFIG ==='; cmd game list-configs com.mobile.legends 2>&1; " +
                    "echo '=== ROBLOX CONFIG ==='; cmd game list-configs com.roblox.client 2>&1; " +
                    "echo '=== FREE FIRE MAX CONFIG ==='; cmd game list-configs com.dts.freefiremax 2>&1; " +
                    "echo '=== CPU POLICY READINGS ==='; for d in /sys/devices/system/cpu/cpufreq/policy*; do [ -d \"$d\" ] || continue; echo ---$d---; for f in scaling_driver scaling_governor scaling_min_freq scaling_max_freq scaling_cur_freq cpuinfo_min_freq cpuinfo_max_freq; do [ -r \"$d/$f\" ] && echo \"$f: $(cat \"$d/$f\" 2>/dev/null)\"; done; done; " +
                    "echo '=== THERMAL SERVICE ==='; dumpsys thermalservice 2>&1 | head -n 65; " +
                    "echo '=== CPU/GPU WRITE ACCESS IS NOT TESTED OR MODIFIED ==='; echo 'Scan is read-only.'";
            String result = runShell(script);
            final String display = result == null || result.trim().isEmpty() ? "No output returned. Check Shizuku status and retry." : result;
            runOnUiThread(() -> {
                outputText.setText(display);
                updateStatus();
                updateThermalStatus();
            });
        }).start();
    }

    private String runShell(String command) {
        Process process = null;
        try {
            process = startShizukuProcess(new String[]{"sh", "-c", command});

            boolean finished = process.waitFor(12, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                return "Scan timed out after 12 seconds. Try again.\n";
            }
            StringBuilder out = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (out.length() < 18000) out.append(line).append('\n');
                }
            }
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null && out.length() < 18000) out.append("[stderr] ").append(line).append('\n');
            }
            return out.toString();
        } catch (Exception e) {
            return "Diagnostic command failed: " + e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            if (process != null) process.destroy();
        }
    }

    /*
     * Shizuku API 13.1.5 keeps newProcess() non-public, although older examples
     * call it directly. Resolve it reflectively so this project compiles against
     * the declared API. Runtime access can still depend on the Shizuku version.
     */
    private Process startShizukuProcess(String[] command) throws Exception {
        java.lang.reflect.Method method = Shizuku.class.getDeclaredMethod(
                "newProcess", String[].class, String[].class, String.class);
        method.setAccessible(true);
        try {
            return (Process) method.invoke(null, command, null, null);
        } catch (java.lang.reflect.InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof Exception) throw (Exception) cause;
            throw e;
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
