# SparkBoost Lab — initial device-specific prototype

Target: Tecno SPARK 50 5G / HiOS 16.2.0 / Android 16.

## Features

- Shizuku connection and permission status.
- Read-only diagnostics for Android Game Manager, CPU policy readings, and thermal service output.
- Android thermal severity status using the public `PowerManager` API.
- One-tap launch buttons for MLBB, Roblox, and Free Fire MAX.
- Optional GPU-light profile: configures Android Game Manager custom mode with an 80% render scale, then reads back the reported config and mode.
- Restore action: resets the custom Game Manager override and selects standard mode, then reads back the reported config and mode.

## Limits and safety

This is an initial prototype, not a validated universal FPS booster. The 80% render scale may reduce GPU workload in GPU-bound scenes, but it also reduces image sharpness and is not guaranteed to improve frame rate. It does not unlock unsupported FPS or directly force CPU/GPU frequencies. On this phone, ADB shell cannot write the observed CPU frequency control files, and the earlier diagnostics showed no preconfigured Game Manager interventions. The app tests Android's custom-mode interface only when the user explicitly taps Apply.

Shizuku does not equal root. It provides shell-level access only within the permissions Android grants; commands may be rejected by the OS or OEM. The app runs only fixed, built-in commands and does not take arbitrary shell text from the user.

## Build status

The source project has not been compiled into an APK in the current environment: Android SDK/build tools are absent, and external downloads are unavailable here. Therefore this archive contains source code, not an installable APK binary.

## Build in Android Studio

1. Install Android Studio and Android SDK Platform 36.
2. Open this folder as an existing Gradle project.
3. Allow Gradle to resolve `dev.rikka.shizuku:api:13.1.5` from Maven Central.
4. Build > Build APK(s). The debug APK should be created under `app/build/outputs/apk/debug/`.
5. Install and start Shizuku using its documented method for your Android version. Open SparkBoost Lab and grant its permission.
6. Run the read-only scan first. If you choose to apply the GPU-light profile, read the confirmation, then check the output for the configuration and mode reported by Android. Use Restore if needed.

## Further development

Only add more controls after verifying a supported Android/Transsion/MediaTek interface and testing that changes can be read back and reversed. Do not add CPU/GPU sysfs writes without a legitimate authorized mechanism.
