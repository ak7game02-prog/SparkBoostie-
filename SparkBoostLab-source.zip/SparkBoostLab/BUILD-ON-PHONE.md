# Build the APK using only your phone

This project can be compiled by GitHub Actions so you do not need a PC. You will need a GitHub account and a web browser on your phone. The source code will be uploaded to a repository you control; do not add passwords or private keys.

1. Open https://github.com/new in your phone browser and create a repository named `SparkBoostLab`. A private repository is fine. Do not initialize it with a README, license, or `.gitignore`.
2. Extract `SparkBoostLab-source.zip` using your phone's file manager or archive app.
3. Open the new repository on GitHub in your browser. Use **Add file → Upload files**. Upload the *contents* of the extracted `SparkBoostLab` folder, including the hidden `.github` folder and `.github/workflows/build-apk.yml`. If the mobile page hides dot-folders or cannot upload folders, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste the workflow content from the project, then upload the other files. Ensure the root of the repo contains `settings.gradle`, `build.gradle`, and the `app` folder.
4. Open the repository's **Actions** tab and choose **Build SparkBoost Lab APK**. If prompted, enable workflows. Tap **Run workflow** if no run starts automatically after uploading.
5. Open the completed workflow run. Under **Artifacts**, download `SparkBoost-Lab-debug-APK`. Extract the downloaded artifact ZIP; inside is `app-debug.apk`.
6. Tap `app-debug.apk` to install. Android may ask you to allow installs from your browser or file manager. Only install the APK you built from this source repository.

## Build caveat

A successful cloud build proves the source compiles; it does not prove every feature works on your phone. The render-scale profile is optional and should be tested cautiously. This is a debug-signed APK, suitable for personal testing, not Play Store publication.
